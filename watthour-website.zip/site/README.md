# WattHour — starter build

This is a working static website implementing the niche plan (portable power stations & home backup power), ready to deploy and expand.

## What's actually built (18 pages)
- Homepage with a working sizing calculator (vanilla JS, no framework)
- All 9 category hub pages, each listing every planned article for that category — live ones link out, the rest are marked "Coming soon" as your content roadmap
- 8 fully written, publish-ready articles spread across categories, demonstrating the hub-and-spoke + cross-category internal linking strategy from the plan:
  - `/guides/how-does-a-portable-power-station-work.html`
  - `/guides/watt-hours-explained.html`
  - `/home-backup/what-size-power-station-do-i-need.html` (includes the full calculator)
  - `/home-backup/how-long-will-a-power-station-run-my-refrigerator.html`
  - `/home-backup/power-station-vs-gas-generator.html`
  - `/home-backup/hurricane-season-power-outage-prep-checklist.html`
  - `/camping-outdoor/how-to-power-a-cpap-machine-while-camping.html`
  - `/buying-guides/best-power-station-for-cpap-machines.html`
- `robots.txt` and `sitemap.xml` (update the domain — currently placeholder `example.com` — before launch)
- Ad slots (`.ad-slot` divs) already placed in the layout — leaderboard, in-article, and rectangle — ready for your AdSense unit code

## Why these 8 articles specifically
They're the lowest-risk starting set: informational/comparative content that doesn't depend on a specific product's live price or spec sheet, so nothing goes stale the week after publishing. The remaining 88 titles from the content plan are already laid out on their category pages as your roadmap — writing them (especially the 14 product reviews) will need current, verified specs and prices pulled from manufacturer pages at the time you publish, not invented numbers, which is why they weren't pre-written here.

## Before you publish this for real
1. **Swap `example.com` for your actual domain** in every `<link rel="canonical">`, the JSON-LD, and `sitemap.xml`.
2. **Add real Privacy Policy, About, Contact, and Affiliate Disclosure pages** — the footer links are placeholders (`#`). AdSense approval generally requires a real privacy policy page.
3. **Apply for AdSense** once you have ~20-30 live articles (see the plan's publishing schedule) — drop your ad unit code into the `.ad-slot` divs.
4. **Verify every product spec before writing reviews** — check current price, capacity, and features directly against the manufacturer's page at time of writing; don't carry over numbers from an old draft.
5. **Run the actual keyword titles through a keyword tool** (Keyword Planner, Ahrefs, Semrush) before finalizing your publishing order — the niche plan's traffic/competition estimates are directional, not a guarantee for any single title.

## Design notes
Typeface: IBM Plex Sans (display/body) + IBM Plex Mono (data/labels), loaded from Google Fonts. Signature visual element is the segmented "charge bar" (`.charge-bar` in `assets/style.css`) — used as the calculator readout, dividers, and rating meters, echoing the LED charge indicator on an actual power station. Fully responsive with a mobile nav toggle in `assets/site.js`.

## Deploying
This is plain HTML/CSS/JS with root-relative paths (`/assets/...`, `/home-backup/...`). Upload the whole `site/` folder to any static host (Netlify, Vercel, Cloudflare Pages, GitHub Pages, or standard hosting) at your domain root — no build step required.
