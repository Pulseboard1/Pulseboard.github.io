// ---- mobile nav ----
document.addEventListener('DOMContentLoaded', function () {
  var toggle = document.querySelector('.nav-toggle');
  var nav = document.querySelector('.primary-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      nav.classList.toggle('open');
      toggle.textContent = nav.classList.contains('open') ? 'CLOSE' : 'MENU';
    });
  }

  // ---- render all charge-bar elements from data-fill (0-100) ----
  document.querySelectorAll('.charge-bar[data-fill]').forEach(renderChargeBar);

  // ---- hero sizing calculator ----
  var calc = document.getElementById('calc-appliances');
  if (calc) {
    var hoursInput = document.getElementById('calc-hours');
    var resultWh = document.getElementById('calc-result-wh');
    var resultNote = document.getElementById('calc-result-note');
    var resultBar = document.getElementById('calc-result-bar');

    function update() {
      var checked = calc.querySelectorAll('input[type=checkbox]:checked');
      var totalWatts = 0;
      checked.forEach(function (c) { totalWatts += parseInt(c.dataset.watts, 10); });
      var hours = parseFloat(hoursInput.value) || 8;
      var rawWh = totalWatts * hours;
      var usableWh = Math.ceil((rawWh / 0.85) / 50) * 50; // round up to nearest 50Wh, 85% usable-capacity factor

      resultWh.textContent = usableWh > 0 ? usableWh.toLocaleString() + ' Wh' : '— Wh';
      resultNote.textContent = usableWh > 0
        ? totalWatts + 'W running load for ' + hours + ' hours, with headroom for battery efficiency losses.'
        : 'Select what you need to power to see a recommended capacity.';

      // scale the visual bar against a 3000Wh reference range
      var pct = Math.min(100, Math.round((usableWh / 3000) * 100));
      if (resultBar) setChargeBar(resultBar, pct);
    }

    calc.addEventListener('change', update);
    hoursInput.addEventListener('input', update);
    update();
  }
});

function renderChargeBar(el) {
  var n = parseInt(el.dataset.n || '12', 10);
  var fill = parseInt(el.dataset.fill || '0', 10);
  setChargeBarSegments(el, n);
  setChargeBar(el, fill);
}

function setChargeBarSegments(el, n) {
  el.style.setProperty('--n', n);
  el.innerHTML = '';
  for (var i = 0; i < n; i++) {
    var s = document.createElement('span');
    el.appendChild(s);
  }
}

function setChargeBar(el, pct) {
  var segs = el.querySelectorAll('span');
  var n = segs.length || 12;
  var litCount = Math.round((pct / 100) * n);
  segs.forEach(function (s, i) {
    s.classList.remove('on', 'full');
    if (i < litCount) {
      s.classList.add('on');
      if (pct >= 90) s.classList.add('full');
    }
  });
}
